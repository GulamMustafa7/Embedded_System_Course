#ifndef MAIN_H
#define MAIN_H

#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>


#define INTERNAL_CMD 0
#define EXTERNAL_CMD 1

int check_command_type(char *);
int execute_external_command(char *);
int execute_internal_command(char *);
void insertNode(int pid);
int fg_bg(char* buff);

#endif

